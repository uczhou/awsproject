#! /bin/bash

cd /home/ubuntu/anntools

/home/ubuntu/.virtualenvs/mpcs/bin/python annotator.py